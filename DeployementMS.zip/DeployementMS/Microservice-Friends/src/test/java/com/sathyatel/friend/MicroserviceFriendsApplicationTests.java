package com.sathyatel.friend;

import org.junit.jupiter.api.Test;
import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration
public class MicroserviceFriendsApplicationTests {

	@Test
	public void contextLoads() {
	}

}
